CREATE OR ALTER VIEW AirportSecurity.MissingPerson AS
	SELECT CONCAT(P.FirstName + ' ', COALESCE(P.MiddleName + ' ',''), P.LastName) Name, DC.CountryName, DC.CountryNameN,
	P.City, P.AddressDetails, P.PhoneNumber, DE.EventTypeName, C.CheckpointName, C.CheckpointLocation, E.EventTime
	FROM dbo.Passenger P
	INNER JOIN dbo.Booking B ON P.PassengerID = B.PassengerID
	INNER JOIN dbo.[Event] E ON B.BookingID = E.BookingID
	INNER JOIN dbo.[Checkpoint] C ON E.CheckpointID = C.CheckpointID
	INNER JOIN dbo.DictEventType DE ON E.EventTypeID = DE.EventTypeID
	INNER JOIN dbo.DictCountry DC ON P.CountryCode = DC.CountryCode
	WHERE E.BagID IS NULL
GO

SELECT * FROM AirportSecurity.MissingPerson