USE Airport
GO
CREATE SCHEMA AirportApp AUTHORIZATION dbo
GO
CREATE APPLICATION ROLE AirportAppRole WITH DEFAULT_SCHEMA = AirportApp, PASSWORD = N'AppPaSSw0rd'
GO
GRANT EXECUTE ON SCHEMA::AirportApp TO AirportAppRole
GO

USE master
GO
CREATE LOGIN AirportAdmin WITH PASSWORD=N'AdmPaSSw0rd', DEFAULT_DATABASE=Airport, CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF
GO
ALTER SERVER ROLE bulkadmin ADD MEMBER AirportAdmin
GO
USE Airport
GO
CREATE USER AirportAdmin FOR LOGIN AirportAdmin
GO
ALTER ROLE db_owner ADD MEMBER AirportAdmin
GO

USE master
GO
CREATE LOGIN AirportEmp WITH PASSWORD=N'EmpPaSSw0rd', DEFAULT_DATABASE=master, CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF
GO
ALTER SERVER ROLE bulkadmin ADD MEMBER AirportEmp
GO
USE Airport
GO
CREATE USER AirportEmp FOR LOGIN AirportEmp
GO
CREATE ROLE AirportEmpRole
GO
ALTER AUTHORIZATION ON ROLE::AirportEmpRole TO dbo
GO
GRANT DELETE ON SCHEMA::dbo TO AirportEmpRole
GRANT EXECUTE ON SCHEMA::dbo TO AirportEmpRole
GRANT INSERT ON SCHEMA::dbo TO AirportEmpRole
GRANT SELECT ON SCHEMA::dbo TO AirportEmpRole
GRANT UPDATE ON SCHEMA::dbo TO AirportEmpRole
GO
DENY DELETE ON dbo.DictCountry TO AirportEmpRole
DENY DELETE ON dbo.DictEventType TO AirportEmpRole
DENY DELETE ON dbo.DictAircraftType TO AirportEmpRole
DENY UPDATE ON dbo.DictAirport TO AirportEmpRole
DENY DELETE ON dbo.DictAirline TO AirportEmpRole
DENY DELETE ON dbo.[Event] TO AirportEmpRole
DENY DELETE ON dbo.[Checkpoint] TO AirportEmpRole
DENY DELETE ON dbo.BagType TO AirportEmpRole
DENY DELETE ON dbo.Aircraft TO AirportEmpRole
DENY DELETE ON dbo.AircraftSeatConfig TO AirportEmpRole
DENY DELETE ON dbo.SeatConfiguration TO AirportEmpRole
GO
ALTER ROLE AirportEmpRole ADD MEMBER AirportEmp
GO

USE master
GO
CREATE LOGIN AirportUser WITH PASSWORD=N'UsePaSSw0rd', DEFAULT_DATABASE=master, CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF
GO
USE Airport
GO
CREATE USER AirportUser	FOR LOGIN AirportUser
GO
ALTER USER AirportUser WITH DEFAULT_SCHEMA=AirportApp
GO
GRANT EXECUTE ON SCHEMA::AirportApp TO AirportUser
GO

USE master
GO
CREATE LOGIN AirportEventHandler WITH PASSWORD=N'EvePaSSw0rd', DEFAULT_DATABASE=master, CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF
GO
USE Airport
GO
CREATE USER AirportEventHandler FOR LOGIN AirportEventHandler
GO
CREATE ROLE AirportEventHandlerRole
GO
ALTER AUTHORIZATION ON ROLE::AirportEventHandlerRole TO dbo
GO
GRANT INSERT ON dbo.Event TO AirportEventHandlerRole
GRANT SELECT ON dbo.Event TO AirportEventHandlerRole
GRANT EXECUTE ON dbo.EventHandler TO AirportEventHandlerRole
GO
GO
ALTER ROLE AirportEventHandlerRole ADD MEMBER AirportEventHandler
GO


USE master
GO
CREATE LOGIN AirportSecurityEmp WITH PASSWORD=N'SecPaSSw0rd', DEFAULT_DATABASE=master, CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF
GO
USE Airport
GO
CREATE USER AirportSecurityEmp FOR LOGIN AirportSecurityEmp
GO
CREATE ROLE AirportSecurityEmpRole
GO
CREATE SCHEMA AirportSecurity AUTHORIZATION dbo
GO
GRANT EXECUTE ON SCHEMA::AirportSecurity TO AirportSecurityEmpRole
GO
ALTER AUTHORIZATION ON ROLE::AirportSecurityEmpRole TO dbo
GO
ALTER ROLE AirportSecurityEmpRole ADD MEMBER AirportSecurityEmp
GO







