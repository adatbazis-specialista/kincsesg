USE Airport
GO

CREATE TABLE dbo.Passenger (
  PassengerID int NOT NULL IDENTITY(1,1),
  FirstName varchar(30) NOT NULL,
  MiddleName varchar(60) NULL,
  LastName varchar(30) NOT NULL,
  PhoneNumber varchar(30) NULL,
  EmailAddress varchar(100) NULL,
  AddressDetails varchar(100) NOT NULL,
  PostalCode varchar(15) NOT NULL,
  City varchar(60) NOT NULL,
  StateProvinceCounty varchar(60) NULL,
  CountryCode char(2) NOT NULL,
  OtherDetails varchar(100) NULL,
  CONSTRAINT PK_Passenger_PassengerID PRIMARY KEY (PassengerID))

CREATE TABLE dbo.Bag (
  BagID int NOT NULL IDENTITY(1,1),
  BagTypeID smallint NOT NULL,
  BagWeight decimal(6,2) NOT NULL,
  BagLength tinyint NOT NULL,
  BagWidth tinyint NOT NULL,
  BagDepth tinyint NOT NULL,
  BookingID int NOT NULL,
  BagStatus bit NOT NULL
	CONSTRAINT DF_Bag_BagStatus DEFAULT 0,
  CONSTRAINT PK_Bag_BagID PRIMARY KEY (BagID))

CREATE TABLE dbo.BagType (
  BagTypeID smallint NOT NULL IDENTITY,
  BagTypeName varchar(60) NOT NULL,
  BagTypeNameN nvarchar(60) NULL,
  AirlineCode char(2) NOT NULL,
  WeightMax decimal(6,2) NOT NULL,
  LengthMax tinyint NOT NULL,
  WidthMax tinyint NOT NULL,
  DepthMax tinyint NOT NULL,
  BagPrice money NOT NULL,
  Surcharge money NOT NULL,
  CONSTRAINT PK_BagType_BagTypeID PRIMARY KEY (BagTypeID))

CREATE TABLE dbo.Booking (
  BookingID int NOT NULL IDENTITY(1,1),
  PassengerID int NOT NULL,
  FlightID int NOT NULL,
  LastPassengerEventID bigint NULL,
  BookingTime datetime2(0) NULL,
  CONSTRAINT PK_Booking_BookingID PRIMARY KEY (BookingID))

CREATE TABLE dbo.Flight (
  FlightID int NOT NULL IDENTITY(1,1),
  FlightNumber varchar(10) NOT NULL,
  AircraftID int NOT NULL,
  OriginAirportCode char(3) NOT NULL,
  DestinationAirportCode char(3) NOT NULL,
  DepartureTime datetime2(0) NOT NULL,
  ArrivalTime datetime2(0) NOT NULL,
  PriceModifier decimal(6,3) NOT NULL,
  CONSTRAINT PK_Flight_FlightID PRIMARY KEY (FlightID))

CREATE TABLE dbo.FlightSeat (
  FlightID int NOT NULL,
  SeatID smallint NOT NULL,
  SeatRowNumber tinyint NOT NULL,
  SeatColumnNumber tinyint NOT NULL,
  SeatCategoryID smallint NOT NULL,
  BookingID int NULL,
  CONSTRAINT PK_FlightSeat_FlightID_SeatID PRIMARY KEY (FlightID, SeatID))

CREATE TABLE dbo.Aircraft (
  AircraftID int NOT NULL IDENTITY(1,1),
  AircraftTypeCode char(3) NOT NULL,
  AirlineCode char(2) NULL,
  CONSTRAINT PK_Aircraft_AircraftID PRIMARY KEY (AircraftID))

CREATE TABLE dbo.SeatConfiguration (
  SeatConfigurationID int NOT NULL,
  SeatID smallint NOT NULL,
  SeatRowNumber tinyint NOT NULL,
  SeatColumnNumber tinyint NOT NULL,
  SeatCategoryID smallint NOT NULL,
  CONSTRAINT PK_SeatConfiguration_SeatConfigurationID_SeatID PRIMARY KEY (SeatConfigurationID, SeatID))
  
CREATE TABLE dbo.AircraftSeatConfig (
  AircraftID int NOT NULL,
  SeatConfigurationID int NOT NULL,
  SeatID smallint NOT NULL,
  CONSTRAINT PK_AircraftSeatConfig_AircraftID_SeatConfigurationID_SeatID PRIMARY KEY (AircraftID, SeatConfigurationID, SeatID))

CREATE TABLE dbo.SeatCategory (
  SeatCategoryID smallint NOT NULL IDENTITY(1,1),
  SeatCategoryName varchar(60) NOT NULL,
  SeatPrice money NOT NULL,
  CONSTRAINT PK_SeatCategory_SeatCategoryID PRIMARY KEY (SeatCategoryID))

CREATE TABLE dbo.[Checkpoint] (
  CheckpointID int NOT NULL IDENTITY(1,1),
  CheckpointName varchar(60) NOT NULL,
  CheckpointNameN nvarchar(60) NULL,
  CheckpointCode varchar(10) NULL,
  CheckpointLocation varchar(100) NULL,
  CONSTRAINT PK_Checkpoint_CheckpointID PRIMARY KEY (CheckpointID))

CREATE TABLE dbo.[Event] (
  EventID bigint NOT NULL IDENTITY(1,1),
  EventTypeID smallint NOT NULL,
  EventTime datetime2(0) NOT NULL,
  CheckpointID int NOT NULL,
  BagID int NULL,
  BookingID int NOT NULL,
  CONSTRAINT PK_Event_EventID PRIMARY KEY (EventID))

CREATE TABLE dbo.DictEventType (
  EventTypeID smallint NOT NULL IDENTITY(1,1),
  EventTypeName varchar(60) NOT NULL,
  EventTypeCode varchar(10) NULL,
  CONSTRAINT PK_DictEventType_EventTypeID PRIMARY KEY (EventTypeID))

CREATE TABLE dbo.DictCountry (
  CountryCode char(2) NOT NULL,
  CountryName varchar(100) NOT NULL,
  CONSTRAINT AK_DictCountry_CountryName UNIQUE (CountryName),
  CountryNameN nvarchar(100) NULL,
  CONSTRAINT PK_DictCountry_CountryCode PRIMARY KEY (CountryCode))

CREATE TABLE dbo.DictAirport (
  AirportCode char(3) NOT NULL,
  AirportName varchar(100) NOT NULL,
  AirportNameN nvarchar(100) NULL,
  CONSTRAINT PK_DictAirport_AirportCode PRIMARY KEY (AirportCode))

CREATE TABLE dbo.DictAirline (
  AirlineCode char(2) NOT NULL,
  AirlineName varchar(100) NOT NULL,
  AirlineNameN nvarchar(100) NULL,
  CONSTRAINT PK_DictAirline_AirlineCode PRIMARY KEY (AirlineCode))

CREATE TABLE dbo.DictAircraftType (
  AircraftTypeCode char(3) NOT NULL,
  AircraftTypeName varchar(100) NOT NULL,
  AircraftTypeNameN nvarchar(100) NULL,
  CONSTRAINT PK_DictAircraftType_AircraftTypeCode PRIMARY KEY (AircraftTypeCode))
  
CREATE TABLE dbo.[Global](
	GlobalID int NOT NULL IDENTITY(1,1),
	GlobalName varchar(50) NOT NULL,
	GlobalValue varchar(1000) NOT NULL,
 CONSTRAINT PK_Global_GlobalID PRIMARY KEY (GlobalID))


ALTER TABLE dbo.Passenger
		DROP CONSTRAINT IF EXISTS FK_Passenger_DictCountry
ALTER TABLE dbo.Passenger
		ADD CONSTRAINT FK_Passenger_DictCountry FOREIGN KEY (CountryCode) REFERENCES dbo.DictCountry (CountryCode)
GO

ALTER TABLE dbo.BagType
		DROP CONSTRAINT IF EXISTS FK_BagType_DictAirline
ALTER TABLE dbo.BagType
		ADD CONSTRAINT FK_BagType_DictAirline FOREIGN KEY (AirlineCode) REFERENCES dbo.DictAirline (AirlineCode)
GO

ALTER TABLE dbo.Bag
		DROP CONSTRAINT IF EXISTS FK_Bag_BagType
ALTER TABLE dbo.Bag
		ADD CONSTRAINT FK_Bag_BagType FOREIGN KEY (BagTypeID) REFERENCES dbo.BagType (BagTypeID)
GO

ALTER TABLE dbo.Bag
		DROP CONSTRAINT IF EXISTS FK_Bag_Booking
ALTER TABLE dbo.Bag
		ADD CONSTRAINT FK_Bag_Booking FOREIGN KEY (BookingID) REFERENCES dbo.Booking (BookingID)
GO

ALTER TABLE dbo.Booking
		DROP CONSTRAINT IF EXISTS FK_Booking_Passenger
ALTER TABLE dbo.Booking
		ADD CONSTRAINT FK_Booking_Passenger FOREIGN KEY (PassengerID) REFERENCES dbo.Passenger (PassengerID)
GO

ALTER TABLE dbo.Booking
		DROP CONSTRAINT IF EXISTS FK_Booking_Flight
ALTER TABLE dbo.Booking
		ADD CONSTRAINT FK_Booking_Flight FOREIGN KEY (FlightID) REFERENCES dbo.Flight (FlightID)
GO

ALTER TABLE dbo.Booking
		DROP CONSTRAINT IF EXISTS FK_Booking_Event
ALTER TABLE dbo.Booking
		ADD CONSTRAINT FK_Booking_Event FOREIGN KEY (LastPassengerEventID) REFERENCES dbo.[Event] (EventID)
GO

ALTER TABLE dbo.Flight
		DROP CONSTRAINT IF EXISTS FK_Flight_Aircraft
ALTER TABLE dbo.Flight
		ADD CONSTRAINT FK_Flight_Aircraft FOREIGN KEY (AircraftID) REFERENCES dbo.Aircraft (AircraftID)
GO

ALTER TABLE dbo.Flight
		DROP CONSTRAINT IF EXISTS FK_Flight_DictAirport_OriginAirportCode
ALTER TABLE dbo.Flight
		ADD CONSTRAINT FK_Flight_DictAirport_OriginAirportCode FOREIGN KEY (OriginAirportCode) REFERENCES dbo.DictAirport (AirportCode)
GO

ALTER TABLE dbo.Flight
		DROP CONSTRAINT IF EXISTS FK_Flight_DictAirport_DestinationAirportCode
ALTER TABLE dbo.Flight
		ADD CONSTRAINT FK_Flight_DictAirport_DestinationAirportCode FOREIGN KEY (DestinationAirportCode) REFERENCES dbo.DictAirport (AirportCode)
GO

ALTER TABLE dbo.FlightSeat
		DROP CONSTRAINT IF EXISTS FK_FlightSeat_Flight
ALTER TABLE dbo.FlightSeat
		ADD CONSTRAINT FK_FlightSeat_Flight FOREIGN KEY (FlightID) REFERENCES dbo.Flight (FlightID)
GO

ALTER TABLE dbo.FlightSeat
		DROP CONSTRAINT IF EXISTS FK_FlightSeat_SeatCategory
ALTER TABLE dbo.FlightSeat
		ADD CONSTRAINT FK_FlightSeat_SeatCategory FOREIGN KEY (SeatCategoryID) REFERENCES dbo.SeatCategory (SeatCategoryID)
GO

ALTER TABLE dbo.FlightSeat
		DROP CONSTRAINT IF EXISTS FK_FlightSeat_Booking
ALTER TABLE dbo.FlightSeat
		ADD CONSTRAINT FK_FlightSeat_Booking FOREIGN KEY (BookingID) REFERENCES dbo.Booking (BookingID)
GO
DROP INDEX IF EXISTS AK_FlightSeat_BookingID ON dbo.FlightSeat
CREATE UNIQUE NONCLUSTERED INDEX AK_FlightSeat_BookingID ON dbo.FlightSeat (BookingID)
		WHERE BookingID IS NOT NULL
GO

ALTER TABLE dbo.Aircraft
		DROP CONSTRAINT IF EXISTS FK_Aircraft_DictAircraftType
ALTER TABLE dbo.Aircraft
		ADD CONSTRAINT FK_Aircraft_DictAircraftType FOREIGN KEY (AircraftTypeCode) REFERENCES dbo.DictAircraftType (AircraftTypeCode)
GO

ALTER TABLE dbo.Aircraft
		DROP CONSTRAINT IF EXISTS FK_Aircraft_DictAirline
ALTER TABLE dbo.Aircraft
		ADD CONSTRAINT FK_Aircraft_DictAirline FOREIGN KEY (AirlineCode) REFERENCES dbo.DictAirline (AirlineCode)
GO

ALTER TABLE dbo.AircraftSeatConfig
		DROP CONSTRAINT IF EXISTS FK_AircraftSeatConfig_Aircraft
ALTER TABLE dbo.AircraftSeatConfig
		ADD CONSTRAINT FK_AircraftSeatConfig_Aircraft FOREIGN KEY (AircraftID) REFERENCES dbo.Aircraft (AircraftID)
GO

ALTER TABLE dbo.AircraftSeatConfig
		DROP CONSTRAINT IF EXISTS FK_AircraftSeatConfig_SeatConfiguration
ALTER TABLE dbo.AircraftSeatConfig
		ADD CONSTRAINT FK_AircraftSeatConfig_SeatConfiguration FOREIGN KEY (SeatConfigurationID, SeatID) REFERENCES dbo.SeatConfiguration (SeatConfigurationID, SeatID)
GO

ALTER TABLE dbo.SeatConfiguration
		DROP CONSTRAINT IF EXISTS FK_SeatConfiguration_SeatCategory
ALTER TABLE dbo.SeatConfiguration
		ADD CONSTRAINT FK_SeatConfiguration_SeatCategory FOREIGN KEY (SeatCategoryID) REFERENCES dbo.SeatCategory (SeatCategoryID)
GO

ALTER TABLE dbo.[Event]
		DROP CONSTRAINT IF EXISTS FK_Event_DictEventType
ALTER TABLE dbo.[Event]
		ADD CONSTRAINT FK_Event_DictEventType FOREIGN KEY (EventTypeID) REFERENCES dbo.DictEventType (EventTypeID)
GO

ALTER TABLE dbo.[Event]
		DROP CONSTRAINT IF EXISTS FK_Event_Checkpoint
ALTER TABLE dbo.[Event]
		ADD CONSTRAINT FK_Event_Checkpoint FOREIGN KEY (CheckpointID) REFERENCES dbo.[Checkpoint] (CheckpointID)
GO

ALTER TABLE dbo.[Event]
		DROP CONSTRAINT IF EXISTS FK_Event_Bag
ALTER TABLE dbo.[Event]
		ADD CONSTRAINT FK_Event_Bag FOREIGN KEY (BagID) REFERENCES dbo.Bag (BagID)
GO

ALTER TABLE dbo.[Event]
		DROP CONSTRAINT IF EXISTS FK_Event_Booking
ALTER TABLE dbo.[Event]
		ADD CONSTRAINT FK_Event_Booking FOREIGN KEY (BookingID) REFERENCES dbo.Booking (BookingID)
GO

DROP INDEX IF EXISTS AK_Checkpoint_CheckpointCode ON dbo.[Checkpoint]
CREATE UNIQUE NONCLUSTERED INDEX AK_Checkpoint_CheckpointCode ON dbo.[Checkpoint] (CheckpointCode)
		WHERE CheckpointCode IS NOT NULL
GO

DROP INDEX IF EXISTS AK_DictEventType_EventTypeCode ON dbo.DictEventType
CREATE UNIQUE NONCLUSTERED INDEX AK_DictEventType_EventTypeCode ON dbo.DictEventType (EventTypeCode)
		WHERE EventTypeCode IS NOT NULL
GO		

DROP INDEX IF EXISTS AK_DictCountry_CountryNameN ON dbo.DictCountry
CREATE UNIQUE NONCLUSTERED INDEX AK_DictCountry_CountryNameN ON dbo.DictCountry (CountryNameN)
		WHERE CountryNameN IS NOT NULL
GO

