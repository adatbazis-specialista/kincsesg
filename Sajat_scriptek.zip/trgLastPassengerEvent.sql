USE Airport
GO

CREATE OR ALTER TRIGGER trgLastPassengerEvent ON dbo.[Event] FOR INSERT
	AS
		UPDATE dbo.Booking
		SET LastPassengerEventID = EventID
		FROM inserted i
		WHERE i.BookingID = dbo.Booking.BookingID
GO
