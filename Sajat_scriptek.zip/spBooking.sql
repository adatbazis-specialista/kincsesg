
CREATE OR ALTER PROC AirportApp.Booking
		@PassengerID int,
		@FlightID int
	AS
		SET NOCOUNT ON
		
		IF @PassengerID IS NULL OR @FlightID IS NULL
			RETURN 1
		ELSE IF EXISTS (SELECT 1
						FROM dbo.Booking B
						WHERE B.PassengerID = @PassengerID AND B.FlightID = @FlightID)
			RETURN 2		
		ELSE IF NOT EXISTS (SELECT 1
						FROM dbo.FlightSeat FS
						WHERE FS.BookingID IS NULL AND FS.FlightID = @FlightID)
			RETURN 3		
		ELSE
			INSERT dbo.Booking (PassengerID, FlightID , BookingTime)
			VALUES (@PassengerID, @FlightID, SYSDATETIME())
GO
	

