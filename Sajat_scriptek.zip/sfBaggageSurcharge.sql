CREATE OR ALTER FUNCTION AirportApp.BaggageSurcharge
	(@BagTypeID smallint,
	 @BagWeight decimal(6,2),
 	 @BagLength tinyint,
 	 @BagWidth tinyint,
	 @BagDepth tinyint)
RETURNS money
AS
BEGIN
	DECLARE @Surcharge money, @S money
	SET @S = (SELECT Surcharge FROM BagType WHERE @BagTypeID = BagTypeID)
	IF @BagWeight > (SELECT WeightMax FROM BagType WHERE @BagTypeID = BagTypeID) SET @Surcharge = @S
	ELSE IF @BagLength > (SELECT LengthMax FROM BagType WHERE @BagTypeID = BagTypeID) SET @Surcharge = @S
	ELSE IF @BagWidth > (SELECT WidthMax FROM BagType WHERE @BagTypeID = BagTypeID) SET @Surcharge = @S
	ELSE IF @BagDepth > (SELECT DepthMax FROM BagType WHERE @BagTypeID = BagTypeID) SET @Surcharge = @S
	ELSE SET @Surcharge = 0
	RETURN @Surcharge
END
GO