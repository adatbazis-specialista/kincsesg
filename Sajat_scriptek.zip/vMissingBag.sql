CREATE OR ALTER VIEW AirportSecurity.MissingBag AS
	SELECT IIF(BAG.BagStatus=1,'G�pre feladva','F�ld�n') BagStatus, CONCAT(P.FirstName + ' ', COALESCE(P.MiddleName + ' ',''), P.LastName)
	Passenger,	DC.CountryName, DC.CountryNameN, P.City, P.PhoneNumber, DE.EventTypeName, C.CheckpointName, C.CheckpointLocation,
	E.EventTime
	FROM dbo.Passenger P
	INNER JOIN dbo.Booking B ON P.PassengerID = B.PassengerID
	INNER JOIN dbo.[Event] E ON B.BookingID = E.BookingID
	INNER JOIN dbo.[Checkpoint] C ON E.CheckpointID = C.CheckpointID
	INNER JOIN dbo.DictEventType DE ON E.EventTypeID = DE.EventTypeID
	INNER JOIN dbo.DictCountry DC ON P.CountryCode = DC.CountryCode
	INNER JOIN dbo.Bag BAG ON E.BagID = BAG.BagID
GO

SELECT * FROM AirportSecurity.MissingBag