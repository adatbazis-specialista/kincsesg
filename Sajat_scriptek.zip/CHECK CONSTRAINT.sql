USE Airport
GO
ALTER TABLE dbo.[Checkpoint] DROP CONSTRAINT IF EXISTS Checkpoint_CheckpointCode
ALTER TABLE dbo.[Checkpoint] ADD CONSTRAINT Checkpoint_CheckpointCode CHECK (CheckpointCode NOT LIKE '%[^A-Z0-9]%')
GO
ALTER TABLE dbo.DictEventType DROP CONSTRAINT IF EXISTS DictEventType_EventTypeCode
ALTER TABLE dbo.DictEventType ADD CONSTRAINT DictEventType_EventTypeCode CHECK (EventTypeCode NOT LIKE '%[^A-Z0-9]%')
GO
ALTER TABLE dbo.Flight DROP CONSTRAINT IF EXISTS CK_Flight_OriginAirportCode_DestinationAirportCode
ALTER TABLE dbo.Flight ADD CONSTRAINT CK_Flight_OriginAirportCode_DestinationAirportCode CHECK (OriginAirportCode <> DestinationAirportCode)
GO
ALTER TABLE dbo.Flight DROP CONSTRAINT IF EXISTS CK_Flight_DepartureTime_ArrivalTime
ALTER TABLE dbo.Flight ADD CONSTRAINT CK_Flight_DepartureTime_ArrivalTime CHECK (DepartureTime <= ArrivalTime)
GO
ALTER TABLE dbo.[Event] DROP CONSTRAINT IF EXISTS CK_Event_EventTime
ALTER TABLE dbo.[Event] ADD CONSTRAINT CK_Event_EventTime CHECK (EventTime <= SYSDATETIME())
GO
