CREATE OR ALTER VIEW AirportApp.BookingPrices AS
	SELECT B.BookingID, CONCAT(P.FirstName + ' ', COALESCE(P.MiddleName + ' ',''), P.LastName) Passenger
	,BT.BagTypeNameN, SUM(BT.BagPrice) "BagPriceSum (EUR)",
	SUM(AirportApp.BaggageSurcharge(BAG.BagTypeID, BAG.BagWeight, BAG.BagLength, Bag.BagWidth, Bag.BagDepth)) "Baggage Surcharge(EUR)"	,
	(SC.SeatPrice * F.PriceModifier) "Ticket Price (EUR)"
	FROM dbo.Passenger P
	INNER JOIN dbo.Booking B ON P.PassengerID = B.PassengerID
	INNER JOIN dbo.Flight F ON B.FlightID = F.FlightID
	LEFT JOIN dbo.FlightSeat FS ON B.BookingID = FS.BookingID
	LEFT JOIN dbo.SeatCategory SC ON FS.SeatCategoryID = SC.SeatCategoryID
	LEFT JOIN dbo.Bag BAG ON B.BookingID = BAG.BookingID
	LEFT JOIN dbo.BagType BT ON BAG.BagTypeID = BT.BagTypeID
	GROUP BY B.BookingID, CONCAT(P.FirstName + ' ', COALESCE(P.MiddleName + ' ',''), P.LastName),
		BT.BagTypeNameN, (SC.SeatPrice * F.PriceModifier)

GO

SELECT * FROM AirportApp.BookingPrices