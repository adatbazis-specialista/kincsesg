
CREATE OR ALTER PROC AirportApp.AddBaggagePrice
		@BagTypeID smallint,
		@BagWeight decimal(6,2),
		@BagLength tinyint,
		@BagWidth tinyint,
		@BagDepth tinyint,
		@BookingID int
	AS
		SET NOCOUNT ON
		
		IF @BagTypeID IS NULL OR @BagWeight IS NULL OR @BagLength IS NULL OR
			@BagWidth IS NULL OR @BagDepth IS NULL OR @BookingID IS NULL
			RETURN 1
		ELSE IF (SELECT AirportApp.BaggageSurcharge (@BagTypeID, @BagWeight, @BagLength, @BagWidth, @BagDepth)) > 0
			RETURN 2
		ELSE
			INSERT dbo.Bag(BagTypeID, BagWeight, BagLength, BagWidth, BagDepth , BookingID)
			VALUES (@BagTypeID, @BagWeight, @BagLength, @BagWidth, @BagDepth, @BookingID)
GO

--DECLARE @RET INT
--EXEC @RET = AirportApp.AddBaggagePrice @BagTypeID = 4, @BagWeight = 11, @BagLength =40, @BagWidth = 30, @BagDepth = 20, @BookingID = NULL 
--SELECT @RET

