USE Airport
GO

INSERT Global(GlobalName, GlobalValue) 
	VALUES ('CountryCodeFile', 'C:\SQL\Adatfelt�lt�s\iso_3166-1_names_unicode.csv')
INSERT Global(GlobalName, GlobalValue) 
	VALUES ('CountryCodeFormatFile', 'C:\SQL\Adatfelt�lt�s\ISO31661NamesUnicodeFormat.xml')


DROP TABLE IF EXISTS #T1

DECLARE @ImportFile varchar(200), @FormatFile varchar(200)
SELECT @ImportFile = GlobalValue FROM Global WHERE GlobalName='CountryCodeFile'
SELECT @FormatFile = GlobalValue FROM Global WHERE GlobalName='CountryCodeFormatFile'
CREATE TABLE #T1 (CountryCode char(2), CountryName varchar(100), CountryNameN nvarchar(100))

DECLARE @S varchar(max) = 'INSERT #T1 
	SELECT * FROM OPENROWSET(BULK ''' + @ImportFile + ''', FORMATFILE=''' + @FormatFile + ''', FIRSTROW=2) S' 
EXEC (@S)
--SELECT * FROM #T1
GO


INSERT DictCountry 
SELECT T1.CountryCode, T1.CountryName, T1.CountryNameN    
FROM #T1 T1
WHERE T1.CountryCode IS NOT NULL AND T1.CountryName IS NOT NULL 

--SELECT * FROM DictCountry
