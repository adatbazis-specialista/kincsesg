USE Airport
GO


INSERT Global(GlobalName, GlobalValue) 
	VALUES ('AircraftsFile', 'C:\SQL\Adatfelt�lt�s\aircrafts.txt')
INSERT Global(GlobalName, GlobalValue) 
	VALUES ('AircraftsFormatFile', 'C:\SQL\Adatfelt�lt�s\AircraftsFormat.xml')


DROP TABLE IF EXISTS #T1

DECLARE @ImportFile varchar(200), @FormatFile varchar(200)
SELECT @ImportFile = GlobalValue FROM Global WHERE GlobalName='AircraftsFile'
SELECT @FormatFile = GlobalValue FROM Global WHERE GlobalName='AircraftsFormatFile'
CREATE TABLE #T1 (AircraftTypeName varchar(100), AircraftTypeCode char(3))

DECLARE @S varchar(max) = 'INSERT #T1 
	SELECT * FROM OPENROWSET(BULK ''' + @ImportFile + ''', FORMATFILE=''' + @FormatFile + ''', FIRSTROW=1) S' 
EXEC (@S)
--SELECT * FROM #T1
GO


INSERT DictAircraftType (AircraftTypeCode, AircraftTypeName)
SELECT T1.AircraftTypeCode, T1.AircraftTypeName   
FROM #T1 T1
WHERE T1.AircraftTypeCode IS NOT NULL AND T1.AircraftTypeName IS NOT NULL 

--SELECT * FROM DictAircraftType
