USE Airport
GO


INSERT Global(GlobalName, GlobalValue) 
	VALUES ('PassengerFile', 'C:\SQL\Adatfelt�lt�s\Passenger.csv')
INSERT Global(GlobalName, GlobalValue) 
	VALUES ('PassengerFormatFile', 'C:\SQL\Adatfelt�lt�s\PassengerFormat.xml')
INSERT Global(GlobalName, GlobalValue) 
	VALUES ('AllCountriesFile', 'C:\SQL\Adatfelt�lt�s\allCountries.txt')
INSERT Global(GlobalName, GlobalValue) 
	VALUES ('AllCountriesFormatFile', 'C:\SQL\Adatfelt�lt�s\AllCountriesFormat.xml')


DROP TABLE IF EXISTS #T1

DECLARE @ImportFile varchar(200), @FormatFile varchar(200)
SELECT @ImportFile = GlobalValue FROM Global WHERE GlobalName='PassengerFile'
SELECT @FormatFile = GlobalValue FROM Global WHERE GlobalName='PassengerFormatFile'
CREATE TABLE #T1 (FirstName varchar(30), MiddleName varchar(60), LastName varchar(30), PhoneNumber varchar(30),
  EmailAddress varchar(100), AddressDetails varchar(100), PostalCode varchar(15), City varchar(60),
  StateProvinceCounty varchar(60), Country varchar(60), OtherDetails varchar(100))

DECLARE @S varchar(max) = 'INSERT #T1 
	SELECT * FROM OPENROWSET(BULK ''' + @ImportFile + ''', FORMATFILE=''' + @FormatFile + ''', FIRSTROW=2) S' 
EXEC (@S)
--SELECT * FROM #T1
GO


INSERT Passenger 
SELECT T1.FirstName, T1.MiddleName, T1.LastName, T1.PhoneNumber, T1.EmailAddress, T1.AddressDetails,
	T1.PostalCode, T1.City, T1.StateProvinceCounty, DC.CountryCode, T1.OtherDetails    
FROM #T1 T1
INNER JOIN DictCountry DC ON T1.Country = DC.CountryName
--SELECT * FROM Passenger
GO


DROP TABLE IF EXISTS #T2

DECLARE @ImportFile varchar(200), @FormatFile varchar(200)
SELECT @ImportFile = GlobalValue FROM Global WHERE GlobalName='AllCountriesFile'
SELECT @FormatFile = GlobalValue FROM Global WHERE GlobalName='AllCountriesFormatFile'
CREATE TABLE #T2 (CountryCode char(2), PostalCode varchar(15), City varchar(180), StateProvinceCounty varchar(60))

DECLARE @S varchar(max) = 'INSERT #T2 
	SELECT * FROM OPENROWSET(BULK ''' + @ImportFile + ''', FORMATFILE=''' + @FormatFile + ''', FIRSTROW=2) S' 
EXEC (@S)
--SELECT * FROM #T2
GO


DELETE #T2
FROM #T2 T2
LEFT JOIN DictCountry DC ON T2.CountryCode = DC.CountryCode
WHERE DC.CountryCode IS NULL
--SELECT * FROM #T2
GO


UPDATE Passenger
SET PostalCode = T2.PostalCode, StateProvinceCounty = T2.StateProvinceCounty, CountryCode = T2.CountryCode
FROM Passenger P
INNER JOIN #T2 T2 ON UPPER(P.City) = UPPER(T2.City)
--SELECT * FROM Passenger
GO
