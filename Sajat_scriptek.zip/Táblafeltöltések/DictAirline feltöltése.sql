USE Airport
GO


INSERT Global(GlobalName, GlobalValue) 
	VALUES ('AirlinesFile', 'C:\SQL\Adatfelt�lt�s\airlines.txt')
INSERT Global(GlobalName, GlobalValue) 
	VALUES ('AirlinesFormatFile', 'C:\SQL\Adatfelt�lt�s\AirlinesFormat.xml')


DROP TABLE IF EXISTS #T1

DECLARE @ImportFile varchar(200), @FormatFile varchar(200)
SELECT @ImportFile = GlobalValue FROM Global WHERE GlobalName='AirlinesFile'
SELECT @FormatFile = GlobalValue FROM Global WHERE GlobalName='AirlinesFormatFile'
CREATE TABLE #T1 (AirlineName varchar(100), AirlineCode char(2))

DECLARE @S varchar(max) = 'INSERT #T1 
	SELECT * FROM OPENROWSET(BULK ''' + @ImportFile + ''', FORMATFILE=''' + @FormatFile + ''', FIRSTROW=1) S' 
EXEC (@S)
--SELECT * FROM #T1
GO


INSERT DictAirline (AirlineCode, AirlineName)
SELECT T1.AirlineCode, T1.AirlineName   
FROM #T1 T1
WHERE T1.AirlineCode IS NOT NULL AND T1.AirlineName IS NOT NULL 

--SELECT * FROM DictAirline
