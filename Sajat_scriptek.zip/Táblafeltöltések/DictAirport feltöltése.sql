USE Airport
GO


INSERT Global(GlobalName, GlobalValue) 
	VALUES ('AirportsFile', 'C:\SQL\Adatfelt�lt�s\airports.txt')
INSERT Global(GlobalName, GlobalValue) 
	VALUES ('AirportsFormatFile', 'C:\SQL\Adatfelt�lt�s\AirportsFormat.xml')


DROP TABLE IF EXISTS #T1

DECLARE @ImportFile varchar(200), @FormatFile varchar(200)
SELECT @ImportFile = GlobalValue FROM Global WHERE GlobalName='AirportsFile'
SELECT @FormatFile = GlobalValue FROM Global WHERE GlobalName='AirportsFormatFile'
CREATE TABLE #T1 (AirportName varchar(100), AirportCode char(3))

DECLARE @S varchar(max) = 'INSERT #T1 
	SELECT * FROM OPENROWSET(BULK ''' + @ImportFile + ''', FORMATFILE=''' + @FormatFile + ''', FIRSTROW=1) S' 
EXEC (@S)
--SELECT * FROM #T1
GO


INSERT DictAirport (AirportCode, AirportName)
SELECT T1.AirportCode, T1.AirportName   
FROM #T1 T1
WHERE T1.AirportCode IS NOT NULL AND T1.AirportName IS NOT NULL 

--SELECT * FROM DictAirport
