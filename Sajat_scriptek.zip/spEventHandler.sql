
CREATE OR ALTER PROC dbo.EventHandler
		@EventTypeID smallint,
		@EventTime datetime2(0),
		@CheckpointID int,
		@BagID int,
		@BookingID int
	AS
		SET NOCOUNT ON
		
		IF @EventTypeID IS NULL OR @EventTime IS NULL OR @CheckpointID IS NULL OR @BookingID IS NULL
			RETURN 1
		ELSE IF EXISTS (SELECT 1
						FROM dbo.[Event] E
						WHERE E.EventTypeID = @EventTypeID AND ABS(DATEDIFF(SECOND, E.EventTime, @EventTime)) < 60
							AND E.CheckpointID = @CheckpointID AND E.BookingID = @BookingID)
			RETURN 2		
		ELSE IF @BagID IS NOT NULL AND (@EventTypeID < 14 OR @CheckpointID < 13)
			RETURN 3	
		ELSE
			INSERT dbo.[Event] (EventTypeID, EventTime , CheckpointID, BagID, BookingID)
			VALUES (@EventTypeID, @EventTime, @CheckpointID, @BagID, @BookingID)
GO
	

--EXEC dbo.EventHandler @EventTypeID = 13, @EventTime = '2021-08-20 12:00:00', @CheckpointID = 14,
--			@BagID = NULL, @BookingID = 1
